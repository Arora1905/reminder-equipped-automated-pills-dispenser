// Types
type GameState = 'start' | 'playing' | 'gameOver';
type ObstacleType = 'rock' | 'bush';
type CollectibleType = 'cookie';

interface GameObject {
  x: number;
  y: number;
  width: number;
  height: number;
  speedX: number;
  element: HTMLImageElement;
}

interface Obstacle extends GameObject {
  type: ObstacleType;
}

interface Collectible extends GameObject {
  type: CollectibleType;
  collected: boolean;
}

// Game constants
const GAME_WIDTH = 800;
const GAME_HEIGHT = 400;
const GROUND_HEIGHT = 50;
const GRANNY_WIDTH = 60;
const GRANNY_HEIGHT = 100;
const GRAVITY = 0.5;
const JUMP_FORCE = 15;
const INITIAL_GAME_SPEED = 5;
const MAX_GAME_SPEED = 12;
const GAME_ACCELERATION = 0.0005;
const OBSTACLES_GAP_MIN = 700;
const OBSTACLES_GAP_MAX = 1500;
const COLLECTIBLE_CHANCE = 0.4; // 40% chance of spawning a collectible

// Game variables
let canvas: HTMLCanvasElement;
let ctx: CanvasRenderingContext2D;
let gameState: GameState = 'start';
let score = 0;
let highScore = 0;
let gameSpeed = INITIAL_GAME_SPEED;
const groundY = GAME_HEIGHT - GROUND_HEIGHT;
let obstacles: Obstacle[] = [];
let collectibles: Collectible[] = [];
let nextObstacleDistance = randomBetween(OBSTACLES_GAP_MIN, OBSTACLES_GAP_MAX);

// Granny variables
const grannyX = 100;
let grannyY = groundY - GRANNY_HEIGHT;
let grannyVelocityY = 0;
let isJumping = false;

// Image elements
let grannyImage: HTMLImageElement;
let rockImage: HTMLImageElement;
let bushImage: HTMLImageElement;
let cookieImage: HTMLImageElement;
let backgroundImage: HTMLImageElement;

// Audio elements
let jumpSound: HTMLAudioElement;
let collectSound: HTMLAudioElement;
let hitSound: HTMLAudioElement;
let gameOverSound: HTMLAudioElement;
let backgroundMusic: HTMLAudioElement;

// DOM elements
let startScreen: HTMLElement;
let gameOverScreen: HTMLElement;
let scoreDisplay: HTMLElement;
let finalScoreDisplay: HTMLElement;
let startButton: HTMLElement;
let restartButton: HTMLElement;

// Initialize the game
function init() {
  canvas = document.getElementById('gameCanvas') as HTMLCanvasElement;
  canvas.width = GAME_WIDTH;
  canvas.height = GAME_HEIGHT;
  const context = canvas.getContext('2d');
  if (!context) {
    console.error('Could not get canvas context');
    return;
  }
  ctx = context;

  // Load DOM elements
  const startScreenElement = document.getElementById('start-screen');
  const gameOverScreenElement = document.getElementById('game-over');
  const scoreDisplayElement = document.getElementById('score');
  const finalScoreDisplayElement = document.getElementById('final-score');
  const startButtonElement = document.getElementById('start-button');
  const restartButtonElement = document.getElementById('restart-button');

  if (!startScreenElement || !gameOverScreenElement || !scoreDisplayElement ||
      !finalScoreDisplayElement || !startButtonElement || !restartButtonElement) {
    console.error('Could not find required DOM elements');
    return;
  }

  startScreen = startScreenElement;
  gameOverScreen = gameOverScreenElement;
  scoreDisplay = scoreDisplayElement;
  finalScoreDisplay = finalScoreDisplayElement;
  startButton = startButtonElement;
  restartButton = restartButtonElement;

  // Load images
  grannyImage = new Image();
  grannyImage.src = '/granny-sprite.svg';
  rockImage = new Image();
  rockImage.src = '/obstacle-rock.svg';
  bushImage = new Image();
  bushImage.src = '/obstacle-bush.svg';
  cookieImage = new Image();
  cookieImage.src = '/cookie.svg';
  backgroundImage = new Image();
  backgroundImage.src = '/background.svg';

  // Load audio with error handling
  jumpSound = new Audio('/sounds/jump.mp3');
  collectSound = new Audio('/sounds/collect.mp3');
  hitSound = new Audio('/sounds/hit.mp3');
  gameOverSound = new Audio('/sounds/game-over.mp3');
  backgroundMusic = new Audio('/sounds/background-music.mp3');
  backgroundMusic.loop = true;
  backgroundMusic.volume = 0.5;

  // Handle audio errors
  jumpSound.onerror = collectSound.onerror = hitSound.onerror =
  gameOverSound.onerror = backgroundMusic.onerror = () => {
    console.warn('Some audio files could not be loaded. Game will continue without sound.');
  };

  // Add event listeners
  startButton.addEventListener('click', startGame);
  restartButton.addEventListener('click', restartGame);
  document.addEventListener('keydown', handleKeyDown);
  document.addEventListener('keyup', handleKeyUp);
  canvas.addEventListener('touchstart', handleTouchStart);

  // Start game loop
  gameLoop();
}

// Game loop
function gameLoop() {
  update();
  render();
  requestAnimationFrame(gameLoop);
}

// Update game state
function update() {
  if (gameState !== 'playing') return;

  // Update score
  score += Math.floor(gameSpeed) / 10;
  scoreDisplay.textContent = `Score: ${Math.floor(score)}`;

  // Update game speed
  gameSpeed += GAME_ACCELERATION;
  if (gameSpeed > MAX_GAME_SPEED) gameSpeed = MAX_GAME_SPEED;

  // Update granny
  updateGranny();

  // Update obstacles
  updateObstacles();

  // Update collectibles
  updateCollectibles();

  // Check collisions
  checkCollisions();
}

// Update granny position and state
function updateGranny() {
  // Apply gravity
  grannyVelocityY += GRAVITY;
  grannyY += grannyVelocityY;

  // Ground collision
  if (grannyY > groundY - GRANNY_HEIGHT) {
    grannyY = groundY - GRANNY_HEIGHT;
    grannyVelocityY = 0;
    isJumping = false;
  }
}

// Update obstacles
function updateObstacles() {
  // Move obstacles
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].x -= gameSpeed;

    // Remove off-screen obstacles
    if (obstacles[i].x + obstacles[i].width < 0) {
      obstacles.splice(i, 1);
    }
  }

  // Add new obstacle
  nextObstacleDistance -= gameSpeed;
  if (nextObstacleDistance <= 0) {
    spawnObstacle();
    nextObstacleDistance = randomBetween(OBSTACLES_GAP_MIN, OBSTACLES_GAP_MAX);

    // Maybe spawn a collectible
    if (Math.random() < COLLECTIBLE_CHANCE) {
      spawnCollectible();
    }
  }
}

// Update collectibles
function updateCollectibles() {
  for (let i = collectibles.length - 1; i >= 0; i--) {
    collectibles[i].x -= gameSpeed;

    // Remove off-screen collectibles
    if (collectibles[i].x + collectibles[i].width < 0) {
      collectibles.splice(i, 1);
    }
  }
}

// Spawn a new obstacle
function spawnObstacle() {
  const type: ObstacleType = Math.random() < 0.5 ? 'rock' : 'bush';
  const image = type === 'rock' ? rockImage : bushImage;
  const width = type === 'rock' ? 50 : 60;
  const height = type === 'rock' ? 40 : 40;

  const obstacle: Obstacle = {
    x: GAME_WIDTH,
    y: groundY - height,
    width,
    height,
    speedX: gameSpeed,
    type,
    element: image
  };

  obstacles.push(obstacle);
}

// Spawn a collectible
function spawnCollectible() {
  const collectible: Collectible = {
    x: GAME_WIDTH + randomBetween(50, 200),
    y: groundY - randomBetween(70, 150),
    width: 30,
    height: 30,
    speedX: gameSpeed,
    type: 'cookie',
    collected: false,
    element: cookieImage
  };

  collectibles.push(collectible);
}

// Check for collisions
function checkCollisions() {
  const grannyHitbox = {
    x: grannyX + 10,
    y: grannyY + 10,
    width: GRANNY_WIDTH - 20,
    height: GRANNY_HEIGHT - 10
  };

  // Check obstacle collisions
  for (const obstacle of obstacles) {
    if (
      grannyHitbox.x < obstacle.x + obstacle.width &&
      grannyHitbox.x + grannyHitbox.width > obstacle.x &&
      grannyHitbox.y < obstacle.y + obstacle.height &&
      grannyHitbox.y + grannyHitbox.height > obstacle.y
    ) {
      // Collision detected
      try {
        hitSound.currentTime = 0;
        hitSound.play().catch(() => {});
      } catch (e) {
        console.warn('Could not play hit sound');
      }

      endGame();
      return;
    }
  }

  // Check collectible collisions
  for (let i = 0; i < collectibles.length; i++) {
    const collectible = collectibles[i];
    if (!collectible.collected &&
      grannyHitbox.x < collectible.x + collectible.width &&
      grannyHitbox.x + grannyHitbox.width > collectible.x &&
      grannyHitbox.y < collectible.y + collectible.height &&
      grannyHitbox.y + grannyHitbox.height > collectible.y
    ) {
      // Collected!
      collectible.collected = true;

      // Play sound with error handling
      try {
        collectSound.currentTime = 0;
        collectSound.play().catch(() => {});
      } catch (e) {
        console.warn('Could not play collect sound');
      }

      score += 10;
      collectibles.splice(i, 1);
      break;
    }
  }
}

// Render the game
function render() {
  // Clear the canvas
  ctx.clearRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

  // Draw background
  ctx.drawImage(backgroundImage, 0, 0, GAME_WIDTH, GAME_HEIGHT);

  if (gameState === 'playing') {
    // Draw obstacles
    for (const obstacle of obstacles) {
      ctx.drawImage(obstacle.element, obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    }

    // Draw collectibles
    for (const collectible of collectibles) {
      if (!collectible.collected) {
        ctx.drawImage(collectible.element, collectible.x, collectible.y, collectible.width, collectible.height);
      }
    }

    // Draw granny
    ctx.drawImage(grannyImage, grannyX, grannyY, GRANNY_WIDTH, GRANNY_HEIGHT);
  }
}

// Handle key down events
function handleKeyDown(e: KeyboardEvent) {
  if (gameState !== 'playing') return;

  if ((e.code === 'Space' || e.code === 'ArrowUp') && !isJumping) {
    jump();
  } else if (e.code === 'ArrowDown') {
    duck();
  }
}

// Handle key up events
function handleKeyUp(e: KeyboardEvent) {
  if (gameState !== 'playing') return;

  if (e.code === 'ArrowDown') {
    unduck();
  }
}

// Handle touch events
function handleTouchStart() {
  if (gameState === 'playing' && !isJumping) {
    jump();
  }
}

// Make granny jump
function jump() {
  isJumping = true;
  grannyVelocityY = -JUMP_FORCE;

  // Play sound with error handling
  try {
    jumpSound.currentTime = 0;
    jumpSound.play().catch(() => {});
  } catch (e) {
    console.warn('Could not play jump sound');
  }
}

// Make granny duck
function duck() {
  // Ducking logic will be implemented in a future version
  // This could change the sprite or hitbox
}

// Stop ducking
function unduck() {
  // Unduck logic will be implemented in a future version
}

// Start the game
function startGame() {
  gameState = 'playing';
  startScreen.classList.add('hidden');
  gameOverScreen.classList.add('hidden');
  score = 0;
  gameSpeed = INITIAL_GAME_SPEED;
  obstacles = [];
  collectibles = [];
  grannyY = groundY - GRANNY_HEIGHT;
  grannyVelocityY = 0;
  nextObstacleDistance = randomBetween(OBSTACLES_GAP_MIN, OBSTACLES_GAP_MAX);

  // Play background music with error handling
  try {
    backgroundMusic.currentTime = 0;
    backgroundMusic.play().catch(() => {
      console.warn('Could not play background music');
    });
  } catch (e) {
    console.warn('Could not play background music');
  }
}

// End the game
function endGame() {
  gameState = 'gameOver';
  gameOverScreen.classList.remove('hidden');
  finalScoreDisplay.textContent = Math.floor(score).toString();

  if (score > highScore) {
    highScore = score;
  }

  // Stop background music and play game over sound
  try {
    backgroundMusic.pause();
    gameOverSound.currentTime = 0;
    gameOverSound.play().catch(() => {});
  } catch (e) {
    console.warn('Could not play game over sound');
  }
}

// Restart the game
function restartGame() {
  startGame();
}

// Utility function for random numbers
function randomBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1) + min);
}

// Start the game when the page loads
window.addEventListener('load', init);
