import { useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useHealthBotStore } from "@/lib/store";
import { ChatMessage } from "./message";
import { ChatInput } from "./chat-input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function ChatInterface() {
  const messages = useHealthBotStore((state) => state.messages);
  const addMessage = useHealthBotStore((state) => state.addMessage);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const prevMessagesLengthRef = useRef<number>(0);

  // Auto-scroll to the latest message
  useEffect(() => {
    if (prevMessagesLengthRef.current !== messages.length) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      prevMessagesLengthRef.current = messages.length;
    }
  });

  // Send greeting message if there are no messages yet
  useEffect(() => {
    if (messages.length === 0) {
      addMessage("bot", "Hello! I'm your HealthBot assistant. How can I help you today?");
    }
  }, [messages.length, addMessage]);

  return (
    <Card className="w-full max-w-4xl mx-auto shadow-lg">
      <CardHeader className="bg-gradient-to-r from-primary/10 to-secondary/10 flex flex-row items-center gap-3">
        <Avatar className="h-12 w-12 border-2 border-primary/20">
          <AvatarImage src="/images/health-bot-icon.png" alt="HealthBot" />
          <AvatarFallback className="bg-primary/10 text-primary text-sm">HB</AvatarFallback>
        </Avatar>
        <div>
          <CardTitle className="text-primary">HealthBot</CardTitle>
          <CardDescription>Your personal health assistant</CardDescription>
        </div>
      </CardHeader>

      <CardContent className="p-4 h-[50vh] overflow-y-auto">
        <div className="space-y-4 pb-2">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
          <div ref={messagesEndRef} />
        </div>
      </CardContent>

      <CardFooter className="border-t p-4 bg-card">
        <ChatInput />
      </CardFooter>
    </Card>
  );
}
