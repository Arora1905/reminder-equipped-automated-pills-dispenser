import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import type { Message } from "@/lib/store";

interface MessageProps {
  message: Message;
}

export function ChatMessage({ message }: MessageProps) {
  const isBot = message.role === "bot";

  return (
    <div
      className={cn(
        "flex items-start gap-4 py-2",
        isBot ? "justify-start" : "justify-end"
      )}
    >
      {isBot && (
        <Avatar className="mt-1 h-10 w-10 border">
          <AvatarImage src="/images/health-bot-icon.png" alt="HealthBot" />
          <AvatarFallback className="bg-primary/10 text-primary text-xs">HB</AvatarFallback>
        </Avatar>
      )}

      <Card className={cn(
        "max-w-[80%]",
        isBot ? "bg-muted" : "bg-primary text-primary-foreground"
      )}>
        <CardContent className="p-3">
          <p>{message.content}</p>
          <div className={cn(
            "text-xs mt-1",
            isBot ? "text-muted-foreground" : "text-primary-foreground/80"
          )}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </CardContent>
      </Card>

      {!isBot && (
        <Avatar className="mt-1 h-10 w-10 border">
          <AvatarFallback className="bg-primary text-primary-foreground">
            YOU
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
}
