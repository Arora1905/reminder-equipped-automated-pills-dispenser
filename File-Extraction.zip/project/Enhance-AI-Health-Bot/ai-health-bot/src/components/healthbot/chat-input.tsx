import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useHealthBotStore } from "@/lib/store";

export function ChatInput() {
  const [inputValue, setInputValue] = useState("");
  const addMessage = useHealthBotStore((state) => state.addMessage);
  const isLoading = useHealthBotStore((state) => state.isLoading);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    if (!inputValue.trim() || isLoading) return;

    // Add user message to store
    addMessage("user", inputValue);

    // Clear input
    setInputValue("");
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-2">
      <Textarea
        placeholder="Type your health question here..."
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        className="min-h-24 resize-none"
      />
      <div className="flex justify-end">
        <Button
          type="submit"
          disabled={!inputValue.trim() || isLoading}
          className="w-full sm:w-auto"
        >
          {isLoading ? "Thinking..." : "Send Message"}
        </Button>
      </div>
    </form>
  );
}
