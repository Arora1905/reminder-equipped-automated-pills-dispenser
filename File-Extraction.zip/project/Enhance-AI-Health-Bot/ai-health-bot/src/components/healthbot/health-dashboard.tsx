import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useHealthBotStore } from "@/lib/store";

export function HealthDashboard() {
  const healthData = useHealthBotStore((state) => state.healthData);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Your Health Summary</CardTitle>
        </CardHeader>
        <CardContent>
          {healthData.symptoms.length > 0 ? (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-2">Detected Symptoms</h3>
                <div className="flex flex-wrap gap-2">
                  {healthData.symptoms.map((symptom) => (
                    <span
                      key={symptom}
                      className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs"
                    >
                      {symptom}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Recommendations</h3>
                <ul className="text-sm space-y-1 list-disc pl-5">
                  <li>Monitor your symptoms for the next 24-48 hours</li>
                  <li>Stay hydrated and get adequate rest</li>
                  <li>Consider over-the-counter pain relief if needed</li>
                  <li>If symptoms worsen, consult a healthcare professional</li>
                </ul>
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No health data available. Share your symptoms with HealthBot to get personalized recommendations.
            </p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Health Resources</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="text-sm space-y-2">
            <li className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-blue-500" />
              <span className="text-blue-600 hover:underline cursor-pointer">
                Find a doctor near you
              </span>
            </li>
            <li className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-blue-500" />
              <span className="text-blue-600 hover:underline cursor-pointer">
                Emergency services information
              </span>
            </li>
            <li className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-blue-500" />
              <span className="text-blue-600 hover:underline cursor-pointer">
                Symptom checker tool
              </span>
            </li>
            <li className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-blue-500" />
              <span className="text-blue-600 hover:underline cursor-pointer">
                Health tips and articles
              </span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
