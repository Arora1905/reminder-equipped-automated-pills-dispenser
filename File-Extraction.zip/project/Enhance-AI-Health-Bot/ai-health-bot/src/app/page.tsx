"use client";

import { ChatInterface } from "@/components/healthbot/chat-interface";
import { HealthDashboard } from "@/components/healthbot/health-dashboard";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-6 lg:p-8">
      <header className="w-full max-w-7xl mb-8 text-center">
        <h1 className="text-3xl font-bold tracking-tight text-primary">
          HealthBot Assistant
        </h1>
        <p className="text-muted-foreground mt-2">
          Your personal AI health assistant - Ask questions about symptoms, get recommendations, and track your health
        </p>
      </header>

      <div className="w-full max-w-7xl flex flex-col lg:flex-row gap-6">
        <div className="flex-1">
          <ChatInterface />
        </div>
        <div className="lg:w-80">
          <HealthDashboard />
        </div>
      </div>

      <footer className="mt-12 text-center text-sm text-muted-foreground">
        <p>HealthBot is not a substitute for professional medical advice. Always consult with a healthcare provider for medical concerns.</p>
      </footer>
    </main>
  );
}
