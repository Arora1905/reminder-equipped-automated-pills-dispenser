import { create } from 'zustand';
import { nanoid } from 'nanoid';

export type MessageRole = 'user' | 'bot';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

interface HealthState {
  symptoms: string[];
  metrics: {
    lastCheckup?: Date;
    heartRate?: number;
    bloodPressure?: string;
    sleep?: number;
  };
}

interface HealthBotState {
  messages: Message[];
  isLoading: boolean;
  healthData: HealthState;
  addMessage: (role: MessageRole, content: string) => void;
  clearMessages: () => void;
  updateHealthData: (data: Partial<HealthState>) => void;
  addSymptom: (symptom: string) => void;
  removeSymptom: (symptom: string) => void;
}

// Predefined bot responses based on user inputs
const botResponses = {
  greeting: [
    "Hello! I'm your HealthBot assistant. How can I help you today?",
    "Hi there! I'm HealthBot, your personal health assistant. What brings you here today?",
    "Welcome! I'm HealthBot, ready to assist with your health concerns. How are you feeling?",
  ],
  symptom: [
    "I notice you're experiencing {symptom}. How long have you been feeling this way?",
    "I understand you're dealing with {symptom}. Can you tell me if you have any other symptoms?",
    "Thank you for sharing about your {symptom}. How severe would you rate it on a scale of 1-10?",
  ],
  followUp: [
    "Is there anything else about your health you'd like to discuss?",
    "Do you have any other health concerns you'd like to share?",
    "Is there anything specific you'd like to know about your symptoms?",
  ],
  recommendation: [
    "Based on what you've told me, I recommend getting plenty of rest and staying hydrated.",
    "I suggest monitoring your symptoms for the next 24 hours. If they worsen, please consult a healthcare professional.",
    "It might be beneficial to schedule an appointment with your doctor to discuss these symptoms further.",
  ],
  unknown: [
    "I'm not sure I understand. Could you provide more details about how you're feeling?",
    "I'd like to help, but I need more specific information about your health concerns.",
    "I'm still learning! Could you rephrase that or provide more context about your health question?",
  ],
};

// Helper to get a random response from a category
const getRandomResponse = (category: keyof typeof botResponses, replacements?: Record<string, string>) => {
  const responses = botResponses[category];
  let response = responses[Math.floor(Math.random() * responses.length)];

  if (replacements) {
    // Use for...of loop instead of forEach
    for (const [key, value] of Object.entries(replacements)) {
      response = response.replace(`{${key}}`, value);
    }
  }

  return response;
};

export const useHealthBotStore = create<HealthBotState>((set, get) => ({
  messages: [],
  isLoading: false,
  healthData: {
    symptoms: [],
    metrics: {},
  },
  addMessage: (role, content) => {
    const newMessage = {
      id: nanoid(),
      role,
      content,
      timestamp: new Date(),
    };

    set((state) => ({
      messages: [...state.messages, newMessage],
      isLoading: role === 'user', // Set loading when user sends a message
    }));

    // Simulate bot response after user message
    if (role === 'user') {
      // Basic keyword detection
      setTimeout(() => {
        let botResponse = '';
        const lowerContent = content.toLowerCase();
        const currentState = get(); // Use get() to access current state

        // Detect if mentioning symptoms
        const symptomKeywords = [
          'headache', 'pain', 'fever', 'cough', 'sore', 'throat',
          'stomach', 'nausea', 'dizzy', 'tired', 'fatigue', 'ache'
        ];

        const detectedSymptom = symptomKeywords.find(symptom => lowerContent.includes(symptom));

        if (currentState.messages.length === 0) {
          botResponse = getRandomResponse('greeting');
        } else if (detectedSymptom) {
          botResponse = getRandomResponse('symptom', { symptom: detectedSymptom });
          // Add symptom to health data
          set((state) => ({
            healthData: {
              ...state.healthData,
              symptoms: [...state.healthData.symptoms, detectedSymptom],
            },
          }));
        } else if (lowerContent.includes('recommend') || lowerContent.includes('suggest') || lowerContent.includes('help')) {
          botResponse = getRandomResponse('recommendation');
        } else {
          botResponse = getRandomResponse('unknown');
        }

        set((state) => ({
          messages: [...state.messages, {
            id: nanoid(),
            role: 'bot',
            content: botResponse,
            timestamp: new Date(),
          }],
          isLoading: false,
        }));
      }, 1000);
    }
  },
  clearMessages: () => set({ messages: [] }),
  updateHealthData: (data) => set((state) => ({
    healthData: {
      ...state.healthData,
      metrics: {
        ...state.healthData.metrics,
        ...data.metrics,
      },
      symptoms: data.symptoms || state.healthData.symptoms,
    },
  })),
  addSymptom: (symptom) => set((state) => ({
    healthData: {
      ...state.healthData,
      symptoms: [...state.healthData.symptoms, symptom],
    },
  })),
  removeSymptom: (symptom) => set((state) => ({
    healthData: {
      ...state.healthData,
      symptoms: state.healthData.symptoms.filter(s => s !== symptom),
    },
  })),
}));
