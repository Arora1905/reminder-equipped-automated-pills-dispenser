import { useState, useEffect } from "react";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "./components/ui/card";
import { Button } from "./components/ui/button";
import { Switch } from "./components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./components/ui/dialog";
import { Input } from "./components/ui/input";
import { Label } from "./components/ui/label";
import { AvaChatbot } from "./components/AvaChatbot";

type Medication = {
  name: string;
  time: string;
  taken?: boolean;
  lastTaken?: string;
  missedDoses?: number;
};

type AppState = {
  userName: string;
  caretakerContact: string;
  medications: Medication[];
  avatar?: string;
  history: {
    date: string;
    med: string;
    taken: boolean;
  }[];
}

enum Step {
  Splash = 0,
  Onboarding = 1,
  Schedule = 2,
  ConfirmLoad = 3,
  Standby = 4,
  Dispense = 5,
  Profile = 6,
}

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [step, setStep] = useState(Step.Splash);
  // App state
  const [userName, setUserName] = useState("");
  const [caretakerContact, setCaretakerContact] = useState("");
  const [medications, setMedications] = useState<Medication[]>([]);
  const [history, setHistory] = useState<AppState['history']>([]);

  // UI state
  const [modalOpen, setModalOpen] = useState(false);
  const [editIdx, setEditIdx] = useState<number | null>(null);
  const [formName, setFormName] = useState("");
  const [formTime, setFormTime] = useState("");
  const [currentMed, setCurrentMed] = useState<Medication | null>(null);
  const [isAlertActive, setIsAlertActive] = useState(false);
  const [alertSound, setAlertSound] = useState<HTMLAudioElement | null>(null);
  const [notificationSent, setNotificationSent] = useState(false);

  // Initialize alert sound
  useEffect(() => {
    const audio = new Audio("https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3");
    audio.loop = true;
    setAlertSound(audio);

    return () => {
      if (audio) {
        audio.pause();
        audio.src = "";
      }
    };
  }, []);

  // For demo/testing: Trigger dispensing after 10 seconds in standby
  useEffect(() => {
    if (step === Step.Standby && medications.length > 0) {
      const timer = setTimeout(() => {
        triggerDispense(medications[0]);
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [step, medications]);

  // Trigger dispensing and alerts
  const triggerDispense = (med: Medication) => {
    setCurrentMed(med);
    setIsAlertActive(true);
    setStep(Step.Dispense);
    if (alertSound) {
      alertSound.play().catch(e => console.log("Audio play failed:", e));
    }
    // Simulate automatic notification to caretaker after 30 seconds if no response
    setTimeout(() => {
      if (step === Step.Dispense && !notificationSent) {
        setNotificationSent(true);
      }
    }, 30000);
  };

  // Handle medication taken/not taken
  const handleMedicationResponse = (taken: boolean) => {
    if (!currentMed) return;

    // Update medication history
    const now = new Date().toLocaleString();
    setHistory([
      ...history,
      {
        date: now,
        med: currentMed.name,
        taken: taken
      }
    ]);

    // Update medication stats
    setMedications(medications.map(med => {
      if (med.name === currentMed.name) {
        return {
          ...med,
          taken: taken,
          lastTaken: taken ? now : med.lastTaken,
          missedDoses: taken ? (med.missedDoses || 0) : (med.missedDoses || 0) + 1
        };
      }
      return med;
    }));

    // Stop alerts and reset state
    if (alertSound) {
      alertSound.pause();
      alertSound.currentTime = 0;
    }
    setIsAlertActive(false);
    setNotificationSent(false);
    setCurrentMed(null);
    setStep(Step.Standby);
  };

  // Splash effect
  if (step === Step.Splash) {
    setTimeout(() => setStep(Step.Onboarding), 1500);
    return (
      <div className="flex items-center justify-center h-screen bg-background dark">
        <span className="font-bold text-6xl tracking-wide text-blue-600">AVA</span>
        <AvaChatbot />
      </div>
    );
  }

  // Onboarding form
  if (step === Step.Onboarding) {
    return (
      <div className={darkMode ? "dark bg-background min-h-screen" : "bg-background min-h-screen"}>
        <div className="max-w-md mx-auto py-16 px-4 flex flex-col gap-8 items-center">
          <h1 className="text-4xl font-extrabold mb-2">Welcome to AVA</h1>
          <form
            onSubmit={e => {
              e.preventDefault();
              if (!userName.trim() || !caretakerContact.trim()) return;
              setStep(Step.Schedule);
            }}
            className="w-full flex flex-col gap-6"
          >
            <div>
              <Label htmlFor="user-name">Your Name</Label>
              <Input
                id="user-name"
                className="mt-1"
                value={userName}
                onChange={e => setUserName(e.target.value)}
                placeholder="e.g. John Doe"
                required
              />
            </div>
            <div>
              <Label htmlFor="caretaker">Caretaker / Family Contact (email)</Label>
              <Input
                id="caretaker"
                className="mt-1"
                value={caretakerContact}
                onChange={e => setCaretakerContact(e.target.value)}
                placeholder="e.g. family@email.com"
                type="email"
                required
              />
            </div>
            <Button className="mt-4 w-full py-3 text-lg font-bold" type="submit">Continue</Button>
          </form>
        </div>
        <AvaChatbot />
      </div>
    );
  }

  // Add/edit medication logic
  const openModal = (idx: number | null = null) => {
    setEditIdx(idx);
    if (idx !== null && medications[idx]) {
      setFormName(medications[idx].name);
      setFormTime(medications[idx].time);
    } else {
      setFormName("");
      setFormTime("");
    }
    setModalOpen(true);
  };

  const handleSave = () => {
    if (!formName.trim() || !formTime.trim()) return;
    if (editIdx === null || medications[editIdx] === undefined) {
      setMedications([...medications, {
        name: formName,
        time: formTime,
        missedDoses: 0
      }]);
    } else {
      setMedications(
        medications.map((m, i) => (i === editIdx ? {
          ...m,
          name: formName,
          time: formTime
        } : m))
      );
    }
    setModalOpen(false);
    setFormName("");
    setFormTime("");
    setEditIdx(null);
  };

  // Medication schedule setup
  if (step === Step.Schedule) {
    return (
      <div className={darkMode ? "dark bg-background min-h-screen" : "bg-background min-h-screen"}>
        <div className="max-w-xl mx-auto py-10 px-4 flex flex-col gap-6">
          <header className="flex items-center justify-between mb-1">
            <span className="text-2xl font-bold">Set Up Your Medication Schedule</span>
            <div className="flex items-center gap-2">
              <span className="text-sm">Light</span>
              <Switch
                checked={darkMode}
                onCheckedChange={() => setDarkMode(!darkMode)}
                aria-label="Toggle dark mode"
              />
              <span className="text-sm">Dark</span>
            </div>
          </header>

          <section>
            <h2 className="text-lg font-semibold mb-2">Today&apos;s Medications</h2>
            <div className="flex flex-col gap-3">
              {medications.length === 0 ? (
                <p className="text-muted-foreground">No medications scheduled yet.</p>
              ) : (
                medications.map((med, idx) => (
                  <Card key={`${med.name}-${med.time}`} className="flex items-center justify-between px-4 py-3">
                    <div>
                      <span className="text-lg font-medium">{med.name}</span>
                      <span className="ml-4 text-base font-mono">{med.time}</span>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => openModal(idx)}>
                      Edit
                    </Button>
                  </Card>
                ))
              )}
            </div>
          </section>

          <footer className="mt-8 flex flex-col gap-3">
            <Button className="w-full py-5 text-lg font-bold" onClick={() => openModal(null)}>
              + Add Medication
            </Button>
            <Button
              className="w-full py-3 text-lg mt-2 bg-blue-600 text-white"
              type="button"
              disabled={medications.length === 0}
              onClick={() => setStep(Step.ConfirmLoad)}
            >
              Medicines loaded in dispenser →
            </Button>
          </footer>
        </div>

        {/* Modal for Add/Edit Medication */}
        <Dialog open={modalOpen} onOpenChange={setModalOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editIdx === null ? "Add Medication" : "Edit Medication"}</DialogTitle>
            </DialogHeader>
            <form
              onSubmit={e => {
                e.preventDefault();
                handleSave();
              }}
              className="flex flex-col gap-4"
            >
              <div className="flex flex-col gap-2">
                <Label htmlFor="med-name">Medicine Name</Label>
                <Input
                  id="med-name"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="e.g. Aspirin"
                  required
                  autoFocus
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="med-time">Time</Label>
                <Input
                  id="med-time"
                  value={formTime}
                  onChange={e => setFormTime(e.target.value)}
                  placeholder="e.g. 08:00 AM"
                  required
                />
              </div>
              <Button type="submit" className="mt-4 w-full py-3 text-lg font-bold">
                Save
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        <AvaChatbot />
      </div>
    );
  }

  // Step 4 -- Confirmation
  if (step === Step.ConfirmLoad) {
    return (
      <div className={darkMode ? "dark bg-background min-h-screen" : "bg-background min-h-screen"}>
        <div className="max-w-lg mx-auto py-20 px-4 flex flex-col gap-8 items-center">
          <span className="text-blue-600 text-5xl mb-2">💊</span>
          <h2 className="text-2xl font-bold">Did you load all the medicines into the dispenser slots?</h2>
          <Button className="w-full py-4 text-lg bg-blue-600 text-white" onClick={() => setStep(Step.Standby)}>
            Yes, continue
          </Button>
        </div>
        <AvaChatbot />
      </div>
    );
  }

  // Profile dashboard
  if (step === Step.Profile) {
    return (
      <div className={darkMode ? "dark bg-background min-h-screen" : "bg-background min-h-screen"}>
        <div className="max-w-xl mx-auto py-8 px-4 flex flex-col gap-6">
          <header className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-blue-600">Profile</h1>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm">Light</span>
                <Switch
                  checked={darkMode}
                  onCheckedChange={() => setDarkMode(!darkMode)}
                  aria-label="Toggle dark mode"
                />
                <span className="text-sm">Dark</span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setStep(Step.Standby)}>
                Back
              </Button>
            </div>
          </header>

          <Card className="w-full">
            <CardHeader>
              <CardTitle>User Details</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div>
                <Label>Name</Label>
                <div className="text-lg font-medium">{userName}</div>
              </div>
              <div>
                <Label>Caretaker Contact</Label>
                <div className="text-lg">{caretakerContact}</div>
              </div>
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader>
              <CardTitle>Medication Statistics</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {medications.map((med, idx) => (
                <div key={`${med.name}-${idx}`} className="border-b pb-3 last:border-0">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{med.name}</span>
                    <span className="text-sm px-2 py-1 rounded-full bg-blue-100 dark:bg-blue-900">
                      {med.time}
                    </span>
                  </div>
                  <div className="text-sm mt-1 flex justify-between">
                    <span>Last taken: {med.lastTaken || 'Never'}</span>
                    <span className="text-red-500">Missed: {med.missedDoses || 0}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <p className="text-muted-foreground">No activity recorded yet</p>
              ) : (
                <div className="flex flex-col gap-2">
                  {history.slice(-5).reverse().map((entry, idx) => (
                    <div key={`${entry.med}-${entry.date}`} className="flex justify-between items-center py-1 border-b last:border-0">
                      <span>{entry.med}</span>
                      <div className="flex flex-col items-end">
                        <span className={entry.taken ? "text-green-500" : "text-red-500"}>
                          {entry.taken ? "Taken" : "Missed"}
                        </span>
                        <span className="text-xs text-muted-foreground">{entry.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Button className="w-full py-3" onClick={() => setStep(Step.Schedule)}>
            Edit Medication Schedule
          </Button>
        </div>
        <AvaChatbot />
      </div>
    );
  }

  // Dispensing screen with audio-visual alerts
  if (step === Step.Dispense) {
    return (
      <div className={`${darkMode ? "dark" : ""} bg-background min-h-screen ${isAlertActive ? "animate-pulse" : ""}`}>
        <div className="max-w-xl mx-auto py-16 px-4 flex flex-col gap-8 items-center">
          <h1 className="text-3xl font-bold text-red-600 animate-pulse">
            Time to Take Your Medication!
          </h1>

          {currentMed && (
            <Card className="w-full bg-blue-50 dark:bg-blue-900 border-2 border-blue-400 dark:border-blue-700">
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold mb-2">{currentMed.name}</div>
                <div className="text-lg font-medium">{currentMed.time}</div>
              </CardContent>
            </Card>
          )}

          <div className="flex flex-col items-center gap-4 w-full mt-4">
            <span className="text-lg mb-4">Did you take this medication?</span>
            <div className="flex gap-4 w-full">
              <Button
                className="flex-1 py-6 text-xl bg-green-600 hover:bg-green-700"
                onClick={() => handleMedicationResponse(true)}
              >
                Yes, Taken
              </Button>
              <Button
                className="flex-1 py-6 text-xl bg-red-600 hover:bg-red-700"
                onClick={() => handleMedicationResponse(false)}
              >
                No, Skip
              </Button>
            </div>
          </div>

          {notificationSent && (
            <div className="mt-4 p-3 bg-yellow-100 dark:bg-yellow-900 text-center rounded-lg w-full">
              Alert sent to caretaker: {caretakerContact}
            </div>
          )}
        </div>
        <AvaChatbot />
      </div>
    );
  }

  // Standby
  return (
    <div className={darkMode ? "dark bg-background min-h-screen" : "bg-background min-h-screen"}>
      <div className="max-w-xl mx-auto py-12 px-4 flex flex-col gap-8 items-center">
        <header className="w-full flex items-center justify-between">
          <h1 className="text-3xl font-bold text-blue-600 flex items-center gap-2">
            AVA <span className="rounded-full w-3 h-3 bg-blue-600 inline-block"/>
          </h1>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setStep(Step.Profile)}
          >
            Profile
          </Button>
        </header>

        <div className="w-full text-center">
          <span className="block text-xl font-semibold mb-2">Hi {userName},</span>
          <span className="block text-lg">Your dispenser is set and waiting for the next scheduled time.</span>
          <div className="mt-2 text-sm text-muted-foreground">
            For demo purposes, medication will be dispensed in 10 seconds
          </div>
        </div>

        <section className="w-full">
          <h2 className="text-base font-semibold mb-2">Upcoming Doses</h2>
          {medications.length === 0 ? (
            <p>No medications scheduled.</p>
          ) : (
            <div className="flex flex-col gap-2">
              {medications.map((med, idx) => (
                <Card key={`${med.name}-${med.time}`} className="flex flex-row justify-between items-center px-4 py-4">
                  <span className="text-lg">{med.name}</span>
                  <span className="text-base font-mono">{med.time}</span>
                </Card>
              ))}
            </div>
          )}
        </section>

        <footer className="text-center text-sm opacity-60">
          Connected to caretaker: {caretakerContact}
        </footer>
        <AvaChatbot />
      </div>
    </div>
  );
}

export default App;
