import { create } from 'zustand';
import { nanoid } from 'nanoid';

export type MessageRole = 'user' | 'bot';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

interface HealthState {
  symptoms: string[];
  metrics: {
    lastCheckup?: Date;
    heartRate?: number;
    bloodPressure?: string;
    sleep?: number;
  };
}

interface HealthBotState {
  messages: Message[];
  isLoading: boolean;
  healthData: HealthState;
  addMessage: (role: MessageRole, content: string) => void;
  clearMessages: () => void;
  updateHealthData: (data: Partial<HealthState>) => void;
  addSymptom: (symptom: string) => void;
  removeSymptom: (symptom: string) => void;
}

// Predefined bot responses based on user inputs
const botResponses = {
  greeting: [
    "Hello! I'm your AVA health assistant. How can I help you today?",
    "Hi there! I'm AVA, your personal health assistant. What brings you here today?",
    "Welcome! I'm AVA, ready to assist with your health concerns and medication needs. How are you feeling?",
  ],
  symptom: [
    "I notice you're experiencing {symptom}. How long have you been feeling this way?",
    "I understand you're dealing with {symptom}. Can you tell me if you have any other symptoms?",
    "Thank you for sharing about your {symptom}. How severe would you rate it on a scale of 1-10?",
  ],
  followUp: [
    "Is there anything else about your health you'd like to discuss?",
    "Do you have any other health concerns you'd like to share?",
    "Is there anything specific you'd like to know about your symptoms?",
  ],
  recommendation: [
    "Based on what you've told me, I recommend getting plenty of rest and staying hydrated.",
    "I suggest monitoring your symptoms for the next 24 hours. If they worsen, please consult a healthcare professional.",
    "It might be beneficial to schedule an appointment with your doctor to discuss these symptoms further.",
  ],
  medication: [
    "Remember to take your medications as prescribed by your doctor. Don't skip doses, even if you feel better.",
    "It's important to store your medications properly, away from direct sunlight and moisture. If you have any questions about storage, please ask.",
    "If you're experiencing side effects from your medication, please consult your healthcare provider before making any changes to your regimen.",
  ],
  unknown: [
    "I'm not sure I understand. Could you provide more details about how you're feeling?",
    "I'd like to help, but I need more specific information about your health concerns.",
    "I'm still learning! Could you rephrase that or provide more context about your health question?",
  ],
};

// Helper to get a random response from a category
const getRandomResponse = (category: keyof typeof botResponses, replacements?: Record<string, string>) => {
  const responses = botResponses[category];
  let response = responses[Math.floor(Math.random() * responses.length)];

  if (replacements) {
    for (const [key, value] of Object.entries(replacements)) {
      response = response.replace(`{${key}}`, value);
    }
  }

  return response;
};

export const useHealthBotStore = create<HealthBotState>((set, get) => ({
  messages: [],
  isLoading: false,
  healthData: {
    symptoms: [],
    metrics: {},
  },
  addMessage: (role, content) => {
    const newMessage = {
      id: nanoid(),
      role,
      content,
      timestamp: new Date(),
    };

    set((state) => ({
      messages: [...state.messages, newMessage],
      isLoading: role === 'user', // Set loading when user sends a message
    }));

    // Simulate bot response after user message
    if (role === 'user') {
      // Basic keyword detection
      setTimeout(() => {
        let botResponse = '';
        const lowerContent = content.toLowerCase();
        const currentState = get(); // Use get() to access current state

        // Detect if mentioning symptoms
        const symptomKeywords = [
          'headache', 'pain', 'fever', 'cough', 'sore', 'throat',
          'stomach', 'nausea', 'dizzy', 'tired', 'fatigue', 'ache'
        ];

        // Detect medication keywords
        const medicationKeywords = [
          'pill', 'medicine', 'drug', 'prescription', 'dose', 'medication',
          'refill', 'pharmacy', 'tablet', 'capsule', 'side effect'
        ];

        const detectedSymptom = symptomKeywords.find(symptom => lowerContent.includes(symptom));
        const isMedicationQuestion = medicationKeywords.some(keyword => lowerContent.includes(keyword));

        if (currentState.messages.length === 1) { // First user message after initial greeting
          botResponse = getRandomResponse('greeting');
        } else if (detectedSymptom) {
          botResponse = getRandomResponse('symptom', { symptom: detectedSymptom });
          // Add symptom to health data
          set((state) => ({
            healthData: {
              ...state.healthData,
              symptoms: [...state.healthData.symptoms, detectedSymptom],
            },
          }));
        } else if (isMedicationQuestion) {
          botResponse = getRandomResponse('medication');
        } else if (lowerContent.includes('recommend') || lowerContent.includes('suggest') || lowerContent.includes('help')) {
          botResponse = getRandomResponse('recommendation');
        } else if (lowerContent.includes('thank') || lowerContent.includes('bye')) {
          botResponse = "You're welcome! If you have any more questions about your health or medications, feel free to ask anytime.";
        } else {
          botResponse = getRandomResponse('unknown');
        }

        set((state) => ({
          messages: [...state.messages, {
            id: nanoid(),
            role: 'bot',
            content: botResponse,
            timestamp: new Date(),
          }],
          isLoading: false,
        }));
      }, 1000);
    }
  },
  clearMessages: () => set({ messages: [] }),
  updateHealthData: (data) => set((state) => ({
    healthData: {
      ...state.healthData,
      metrics: {
        ...state.healthData.metrics,
        ...data.metrics,
      },
      symptoms: data.symptoms || state.healthData.symptoms,
    },
  })),
  addSymptom: (symptom) => set((state) => ({
    healthData: {
      ...state.healthData,
      symptoms: [...state.healthData.symptoms, symptom],
    },
  })),
  removeSymptom: (symptom) => set((state) => ({
    healthData: {
      ...state.healthData,
      symptoms: state.healthData.symptoms.filter(s => s !== symptom),
    },
  })),
}));
