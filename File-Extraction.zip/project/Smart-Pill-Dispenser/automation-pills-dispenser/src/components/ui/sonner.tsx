"use client"

import type { ToasterProps as SonnerToasterProps } from "sonner";

// Simplified sonner component without next-themes
export type ToasterProps = SonnerToasterProps;

export function Toaster({ ...props }: ToasterProps) {
  return (
    <div id="sonner-provider" className="fixed inset-0 pointer-events-none flex flex-col" />
  );
}
