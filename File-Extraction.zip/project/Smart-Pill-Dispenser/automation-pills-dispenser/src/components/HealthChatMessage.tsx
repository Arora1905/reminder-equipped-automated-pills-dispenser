import React from "react";
import { Card } from "./ui/card";
import { cn } from "../lib/utils";
import type { Message } from "../lib/store";

interface MessageProps {
  message: Message;
}

export function HealthChatMessage({ message }: MessageProps) {
  const isBot = message.role === "bot";

  return (
    <div
      className={cn(
        "flex items-start gap-4 py-2",
        isBot ? "justify-start" : "justify-end"
      )}
    >
      {isBot && (
        <div className="mt-1 h-8 w-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs">
          AVA
        </div>
      )}

      <Card className={cn(
        "max-w-[80%]",
        isBot ? "bg-slate-100 dark:bg-slate-800" : "bg-blue-600 text-white"
      )}>
        <div className="p-3">
          <p className="text-sm">{message.content}</p>
          <div className={cn(
            "text-xs mt-1 text-right",
            isBot ? "text-slate-500 dark:text-slate-400" : "text-blue-100"
          )}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </Card>

      {!isBot && (
        <div className="mt-1 h-8 w-8 rounded-full bg-slate-300 dark:bg-slate-600 text-slate-700 dark:text-slate-200 flex items-center justify-center text-xs">
          YOU
        </div>
      )}
    </div>
  );
}
