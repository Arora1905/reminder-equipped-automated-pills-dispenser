import React, { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "./ui/popover";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Heart, Pill } from "lucide-react";

type Message = {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
};

// Create unique ID
const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const INITIAL_BOT_MESSAGE: Message = {
  id: generateId(),
  text: "Hello! I'm your medication assistant. I can help with medication information, reminders, or answer questions about your pill dispenser. How can I assist you today?",
  sender: "bot",
  timestamp: new Date(),
};

// Sample medication responses
const MEDICATION_RESPONSES = [
  {
    keywords: ["how", "work", "use", "dispenser", "device", "pill", "function"],
    response: "Our AVA pill dispenser works by organizing and dispensing your medications on schedule. Just load your pills in the designated slots, set up your schedule in the app, and the dispenser will alert you when it's time to take your medication. It also notifies your caretaker if you miss a dose.",
  },
  {
    keywords: ["reminder", "remind", "notification", "alert", "alarm"],
    response: "The AVA system uses audible tones, visual alerts, and mobile notifications to remind you when it's time to take your medication. You can customize these alerts in the settings to suit your preferences.",
  },
  {
    keywords: ["missed", "skip", "forget", "late", "dose"],
    response: "If you miss a dose, AVA will send a notification to your assigned caretaker/family member. It's important to follow your doctor's instructions about what to do with missed doses - never double up without medical advice.",
  },
  {
    keywords: ["side effect", "reaction", "adverse"],
    response: "If you're experiencing what you think might be medication side effects, it's important to contact your healthcare provider. Common side effects should be listed in your medication information leaflet, but a healthcare professional can best advise you on your specific situation.",
  },
  {
    keywords: ["interact", "interaction", "combine", "mix", "together", "conflict"],
    response: "Medication interactions can be serious. Always inform your doctor about all medications (including over-the-counter and supplements) you're taking. If you're concerned about potential interactions, please consult your pharmacist or doctor immediately.",
  },
  {
    keywords: ["food", "eat", "meal", "drink", "alcohol", "empty stomach", "full stomach"],
    response: "Some medications need to be taken with food, while others work best on an empty stomach. Some may interact with certain foods or alcohol. Check your prescription information or ask your pharmacist for specific guidance on your medications.",
  },
  {
    keywords: ["refill", "prescription", "renew", "pharmacy", "order", "more"],
    response: "Most prescriptions can be refilled by contacting your pharmacy directly. Many pharmacies offer automatic refill programs. You should refill medications before they run out - typically when you have about a week's supply remaining.",
  },
  {
    keywords: ["store", "storage", "keep", "temperature", "refrigerate"],
    response: "Most medications should be stored in a cool, dry place away from direct sunlight. Some require refrigeration. Always check the label or ask your pharmacist. Also, keep medications in their original containers and out of reach of children.",
  },
  {
    keywords: ["contact", "doctor", "pharmacist", "nurse", "emergency", "help"],
    response: "If you have urgent concerns about your medication, please contact your healthcare provider or pharmacist immediately. For emergencies, call emergency services or go to the nearest emergency room.",
  },
  {
    keywords: ["caretaker", "family", "notify", "alert", "monitor", "track"],
    response: "The AVA system allows a designated caretaker or family member to receive notifications about your medication adherence. They'll be alerted if you miss a dose, helping to ensure you stay on track with your treatment plan.",
  }
];

export function MedicalSupport() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_BOT_MESSAGE]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };
    setMessages([...messages, userMessage]);
    setInputValue("");

    // Simulate bot thinking
    setIsTyping(true);

    setTimeout(() => {
      // Find relevant response or use default
      const botResponse = findMedicationResponse(inputValue);

      const botMessage: Message = {
        id: generateId(),
        text: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const findMedicationResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Check for app-specific questions first
    if (lowerQuery.includes("reset") || lowerQuery.includes("restart") || lowerQuery.includes("not working")) {
      return "If you're having technical issues with the AVA dispenser, try powering it off for 30 seconds, then back on. If problems persist, please contact our support team at support@ava-dispenser.com.";
    }

    // Check for general help
    if (lowerQuery.includes("help") && lowerQuery.length < 10) {
      return "I can help with questions about your medications, how to use your pill dispenser, setting reminders, or understanding medication guidance. What specifically would you like assistance with?";
    }

    // Check against keyword patterns
    for (const response of MEDICATION_RESPONSES) {
      if (response.keywords.some(keyword => lowerQuery.includes(keyword))) {
        return response.response;
      }
    }

    // Default response
    return "I understand you might have questions about your medications or dispenser. Could you provide more details about what you'd like to know? I'm here to help with medication information, reminders, and dispenser usage.";
  };

  return (
    <div className="fixed bottom-5 left-5 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            className="h-14 w-14 rounded-full bg-green-600 hover:bg-green-700 shadow-lg"
            aria-label="Open medication assistant"
          >
            <Pill className="h-6 w-6" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 sm:w-96 p-0 max-h-[500px] flex flex-col" side="top">
          <div className="bg-green-600 text-white p-3 rounded-t-lg">
            <h3 className="font-bold">Medication Assistant</h3>
            <p className="text-xs opacity-90">Ask about medications or pill dispenser help</p>
          </div>

          <div className="flex-1 p-3 overflow-y-auto max-h-[350px] flex flex-col gap-2">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`${
                  message.sender === "bot"
                    ? "bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start max-w-[85%]"
                    : "bg-green-600 text-white rounded-lg p-2 self-end max-w-[85%]"
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                  {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
            ))}

            {isTyping && (
              <div className="bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start animate-pulse">
                <p className="text-sm">Typing...</p>
              </div>
            )}
          </div>

          <div className="p-3 border-t flex gap-2">
            <Textarea
              placeholder="Ask about medication or dispenser help..."
              className="resize-none min-h-[60px]"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              className="bg-green-600 hover:bg-green-700"
            >
              Send
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
