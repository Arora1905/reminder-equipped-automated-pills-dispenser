import React, { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "./ui/popover";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { MessageCircle } from "lucide-react";

type Message = {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
};

// Create unique ID
const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const INITIAL_BOT_MESSAGE: Message = {
  id: generateId(),
  text: "Hello! I'm AVA, your medication and health assistant. How can I help you today?",
  sender: "bot",
  timestamp: new Date(),
};

// Combined responses for both health and medication
const AVA_RESPONSES = [
  // Pill dispenser and medication specific
  {
    keywords: ["how", "work", "use", "dispenser", "device", "pill", "function"],
    response: "Our AVA pill dispenser works by organizing and dispensing your medications on schedule. Just load your pills in the designated slots, set up your schedule in the app, and the dispenser will alert you when it's time to take your medication. It also notifies your caretaker if you miss a dose.",
  },
  {
    keywords: ["reminder", "remind", "notification", "alert", "alarm"],
    response: "The AVA system uses audible tones, visual alerts, and mobile notifications to remind you when it's time to take your medication. You can customize these alerts in the settings to suit your preferences.",
  },
  {
    keywords: ["missed", "skip", "forget", "late", "dose"],
    response: "If you miss a dose, AVA will send a notification to your assigned caretaker/family member. It's important to follow your doctor's instructions about what to do with missed doses - never double up without medical advice.",
  },
  {
    keywords: ["refill", "prescription", "renew", "pharmacy", "order", "more"],
    response: "Most prescriptions can be refilled by contacting your pharmacy directly. Many pharmacies offer automatic refill programs. You should refill medications before they run out - typically when you have about a week's supply remaining.",
  },
  {
    keywords: ["store", "storage", "keep", "temperature", "refrigerate"],
    response: "Most medications should be stored in a cool, dry place away from direct sunlight. Some require refrigeration. Always check the label or ask your pharmacist. Also, keep medications in their original containers and out of reach of children.",
  },
  {
    keywords: ["contact", "doctor", "pharmacist", "nurse", "emergency", "help"],
    response: "If you have urgent concerns about your medication, please contact your healthcare provider or pharmacist immediately. For emergencies, call emergency services or go to the nearest emergency room.",
  },
  {
    keywords: ["caretaker", "family", "notify", "alert", "monitor", "track"],
    response: "The AVA system allows a designated caretaker or family member to receive notifications about your medication adherence. They'll be alerted if you miss a dose, helping to ensure you stay on track with your treatment plan.",
  },

  // Health-related responses
  {
    keywords: ["headache", "head", "pain", "migraine", "ache"],
    response: "Headaches can be caused by many factors including stress, dehydration, or lack of sleep. If it's severe or persistent, please consult a healthcare professional. Would you like basic remedies for headaches?",
  },
  {
    keywords: ["fever", "temperature", "hot", "chills"],
    response: "Fever is often a sign your body is fighting an infection. Rest, stay hydrated, and consider over-the-counter fever reducers. If your temperature exceeds 103°F (39.4°C) or persists for more than 3 days, please seek medical attention.",
  },
  {
    keywords: ["tired", "fatigue", "exhausted", "energy", "sleep"],
    response: "Fatigue can result from poor sleep, stress, or underlying health conditions. Try improving your sleep habits, staying hydrated, and maintaining a balanced diet. If severe fatigue persists, consider consulting a doctor.",
  },
  {
    keywords: ["cough", "cold", "congestion", "sore throat", "sneeze", "sneezing", "nose", "runny"],
    response: "Common cold symptoms can be managed with rest, fluids, and over-the-counter medications. If symptoms worsen after 7-10 days or include high fever, severe pain, or difficulty breathing, please see a healthcare provider.",
  },

  // App usage
  {
    keywords: ["setup", "configure", "add", "medication", "schedule"],
    response: "To set up your medication schedule: 1) Enter your name and caretaker contact information 2) Tap '+ Add Medication' 3) Enter medication name and time 4) Confirm when all medications are loaded into the dispenser.",
  },
  {
    keywords: ["edit", "change", "update", "modify"],
    response: "You can edit your medication schedule by clicking on the Edit button next to the medication you wish to modify. From the Profile page, you can also click 'Edit Medication Schedule' at the bottom of the screen.",
  },
  {
    keywords: ["theme", "dark", "light", "mode", "display"],
    response: "You can toggle between dark and light mode by using the switch in the top right corner of most screens. This allows you to customize the app's appearance based on your preference or lighting conditions.",
  },
];

export function AvaChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_BOT_MESSAGE]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };
    setMessages([...messages, userMessage]);
    setInputValue("");

    // Simulate bot thinking
    setIsTyping(true);

    setTimeout(() => {
      // Find relevant response or use default
      const botResponse = findResponse(inputValue);

      const botMessage: Message = {
        id: generateId(),
        text: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const findResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Check for emergency keywords first
    if (
      lowerQuery.includes("emergency") ||
      lowerQuery.includes("call 911") ||
      lowerQuery.includes("can't breathe") ||
      (lowerQuery.includes("chest") && lowerQuery.includes("pain"))
    ) {
      return "⚠️ If this is a medical emergency, please call emergency services (911) immediately.";
    }

    // Basic greetings
    if (
      lowerQuery.includes("hello") ||
      lowerQuery.includes("hi") ||
      lowerQuery.includes("hey") ||
      lowerQuery === "hello" ||
      lowerQuery === "hi"
    ) {
      return "Hello! I'm AVA, your medication and health assistant. How can I help you today?";
    }

    // App-specific questions
    if (lowerQuery.includes("what can you do") || lowerQuery.includes("help me")) {
      return "I can help you with information about your medications, answer health questions, explain how to use the AVA pill dispenser, and provide reminders about your medication schedule. What would you like to know?";
    }

    // Check against keyword patterns
    for (const response of AVA_RESPONSES) {
      if (response.keywords.some(keyword => lowerQuery.includes(keyword))) {
        return response.response;
      }
    }

    // Default response
    return "I understand you might have questions. I can help with medication information, health concerns, or how to use the AVA system. Could you please provide more details about what you'd like to know?";
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            className="h-14 w-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
            aria-label="Open AVA assistant"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 sm:w-96 p-0 max-h-[500px] flex flex-col" side="top">
          <div className="bg-blue-600 text-white p-3 rounded-t-lg">
            <h3 className="font-bold">AVA Assistant</h3>
            <p className="text-xs opacity-90">Ask me about medications, health, or the pill dispenser</p>
          </div>

          <div className="flex-1 p-3 overflow-y-auto max-h-[350px] flex flex-col gap-2">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`${
                  message.sender === "bot"
                    ? "bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start max-w-[85%]"
                    : "bg-blue-600 text-white rounded-lg p-2 self-end max-w-[85%]"
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                  {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
            ))}

            {isTyping && (
              <div className="bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start animate-pulse">
                <p className="text-sm">Typing...</p>
              </div>
            )}
          </div>

          <div className="p-3 border-t flex gap-2">
            <Textarea
              placeholder="Ask AVA anything..."
              className="resize-none min-h-[60px]"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Send
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
