import React, { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "./ui/popover";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Plus } from "lucide-react";

type Message = {
  id: string; // Add unique ID
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
};

// Create unique ID
const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const INITIAL_BOT_MESSAGE: Message = {
  id: generateId(),
  text: "Hello! I'm your health assistant. I can help answer health questions or check symptoms. How are you feeling today?",
  sender: "bot",
  timestamp: new Date(),
};

// Sample health responses - in a real app this would connect to a medical AI API
const HEALTH_RESPONSES = [
  {
    keywords: ["headache", "head", "pain", "migraine", "ache"],
    response: "Headaches can be caused by many factors including stress, dehydration, or lack of sleep. If it's severe or persistent, please consult a healthcare professional. Would you like basic remedies for headaches?",
  },
  {
    keywords: ["fever", "temperature", "hot", "chills"],
    response: "Fever is often a sign your body is fighting an infection. Rest, stay hydrated, and consider over-the-counter fever reducers. If your temperature exceeds 103°F (39.4°C) or persists for more than 3 days, please seek medical attention.",
  },
  {
    keywords: ["tired", "fatigue", "exhausted", "energy", "sleep"],
    response: "Fatigue can result from poor sleep, stress, or underlying health conditions. Try improving your sleep habits, staying hydrated, and maintaining a balanced diet. If severe fatigue persists, consider consulting a doctor.",
  },
  {
    keywords: ["cough", "cold", "congestion", "sore throat", "sneeze", "sneezing", "nose", "runny"],
    response: "Common cold symptoms can be managed with rest, fluids, and over-the-counter medications. If symptoms worsen after 7-10 days or include high fever, severe pain, or difficulty breathing, please see a healthcare provider.",
  },
  {
    keywords: ["stomach", "nausea", "vomit", "diarrhea", "constipation", "digestive"],
    response: "Digestive issues can range from mild food sensitivity to more serious conditions. Stay hydrated and consider bland foods. If symptoms include severe pain, blood in stool, or persist for more than a few days, please consult a doctor.",
  },
  {
    keywords: ["dizzy", "dizziness", "vertigo", "lightheaded", "faint"],
    response: "Dizziness can be caused by many factors including dehydration, inner ear issues, or low blood pressure. Sit or lie down immediately if feeling dizzy. If dizziness is severe, persistent, or accompanied by other symptoms, seek medical attention.",
  },
  {
    keywords: ["heart", "chest", "pain", "pressure", "palpitation"],
    response: "⚠️ IMPORTANT: Chest pain or pressure could indicate a serious condition requiring immediate medical attention. Please call emergency services or go to the nearest emergency room immediately if experiencing these symptoms.",
  },
  {
    keywords: ["medication", "medicine", "pill", "drug", "prescription", "side effect"],
    response: "Questions about medications should be directed to your healthcare provider or pharmacist. Never change dosages or stop prescribed medications without consulting your doctor first.",
  },
];

export function HealthChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_BOT_MESSAGE]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };
    setMessages([...messages, userMessage]);
    setInputValue("");

    // Simulate bot thinking
    setIsTyping(true);

    setTimeout(() => {
      // Find relevant response or use default
      const botResponse = findHealthResponse(inputValue);

      const botMessage: Message = {
        id: generateId(),
        text: botResponse,
        sender: "bot",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botMessage]);
      setIsTyping(false);
    }, 1000);
  };

  const findHealthResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Check for emergency keywords first
    if (
      lowerQuery.includes("emergency") ||
      lowerQuery.includes("call 911") ||
      lowerQuery.includes("can't breathe") ||
      (lowerQuery.includes("chest") && lowerQuery.includes("pain"))
    ) {
      return "⚠️ If this is a medical emergency, please call emergency services (911) immediately.";
    }

    // Check against keyword patterns
    for (const response of HEALTH_RESPONSES) {
      if (response.keywords.some(keyword => lowerQuery.includes(keyword))) {
        return response.response;
      }
    }

    // Default response
    return "I understand you might have health concerns. While I can offer general information, it's best to consult a healthcare professional for personalized advice. Can you tell me more about your symptoms?";
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            className="h-14 w-14 rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg"
            aria-label="Open health assistant"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 sm:w-96 p-0 max-h-[500px] flex flex-col">
          <div className="bg-blue-600 text-white p-3 rounded-t-lg">
            <h3 className="font-bold">Health Assistant</h3>
            <p className="text-xs opacity-90">Ask about symptoms or health concerns</p>
          </div>

          <div className="flex-1 p-3 overflow-y-auto max-h-[350px] flex flex-col gap-2">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`${
                  message.sender === "bot"
                    ? "bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start max-w-[85%]"
                    : "bg-blue-600 text-white rounded-lg p-2 self-end max-w-[85%]"
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                  {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
            ))}

            {isTyping && (
              <div className="bg-slate-100 dark:bg-slate-800 rounded-lg p-2 self-start animate-pulse">
                <p className="text-sm">Typing...</p>
              </div>
            )}
          </div>

          <div className="p-3 border-t flex gap-2">
            <Textarea
              placeholder="Type your health question..."
              className="resize-none min-h-[60px]"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Send
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
