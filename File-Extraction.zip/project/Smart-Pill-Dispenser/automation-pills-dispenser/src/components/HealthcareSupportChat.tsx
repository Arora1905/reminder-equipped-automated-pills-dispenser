import React, { useState } from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger
} from "./ui/popover";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { MessageSquareText, Heart } from "lucide-react";

type Message = {
  id: string;
  text: string;
  sender: "user" | "support";
  timestamp: Date;
};

// Create unique ID
const generateId = () => Math.random().toString(36).substring(2, 9) + Date.now().toString(36);

const INITIAL_SUPPORT_MESSAGE: Message = {
  id: generateId(),
  text: "Hello! I'm your Healthcare Support Agent. I can help with medication information, scheduling concerns, and connect you with healthcare providers. How can I assist you today?",
  sender: "support",
  timestamp: new Date(),
};

// Healthcare support responses - focused on medication management and healthcare system navigation
const HEALTHCARE_RESPONSES = [
  {
    keywords: ["side effect", "reaction", "adverse"],
    response: "Side effects should be taken seriously. Could you tell me which medication is causing concerns? Make sure to document any symptoms and contact your healthcare provider right away if severe.",
  },
  {
    keywords: ["missed", "dose", "forget", "forgot", "missing", "skip", "skipped"],
    response: "Missing a dose happens occasionally. For most medications, take it when you remember unless it's almost time for your next dose. Never double up on doses. Each medication has specific guidelines, so check with your pharmacist or doctor for your specific case.",
  },
  {
    keywords: ["refill", "renew", "prescription", "ran out", "pharmacy"],
    response: "For prescription refills, contact your pharmacy 2-3 days before running out. Many pharmacies offer auto-refill programs and mobile apps to make the process easier. Would you like tips on setting up medication reminders?",
  },
  {
    keywords: ["cost", "expensive", "afford", "price", "insurance", "coverage"],
    response: "Medication costs can be challenging. Ask your doctor about generic alternatives, patient assistance programs, or prescription discount cards. Many pharmaceutical companies also offer financial assistance programs for eligible patients.",
  },
  {
    keywords: ["interaction", "mix", "together", "combine", "conflict"],
    response: "Drug interactions are important to monitor. Always inform your healthcare providers about ALL medications you're taking, including over-the-counter drugs, supplements, and herbs. Your pharmacist can also check for potential interactions.",
  },
  {
    keywords: ["doctor", "appointment", "visit", "provider", "specialist", "referral"],
    response: "I can help you prepare for your doctor's appointment. It's useful to bring your medication list, write down your symptoms or concerns beforehand, and prepare specific questions. Would you like help organizing your health information?",
  },
  {
    keywords: ["caregiver", "family", "help", "assist", "support"],
    response: "Caregivers play a vital role in medication management. Setting up pill organizers, medication schedules, and reminders can help. Consider using our caregiver notification feature to keep family members informed about medication adherence.",
  },
  {
    keywords: ["dispenser", "device", "machine", "pill", "reminder", "alarm"],
    response: "Your AVA pill dispenser is designed to simplify medication management. It provides scheduled dispensing, reminders, and can alert caregivers if doses are missed. Would you like me to explain any specific feature of your pill dispenser?",
  },
];

export function HealthcareSupportChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_SUPPORT_MESSAGE]);
  const [inputValue, setInputValue] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    };
    setMessages([...messages, userMessage]);
    setInputValue("");

    // Simulate support agent typing
    setIsTyping(true);

    setTimeout(() => {
      // Find relevant response or use default
      const supportResponse = findSupportResponse(inputValue);

      const supportMessage: Message = {
        id: generateId(),
        text: supportResponse,
        sender: "support",
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, supportMessage]);
      setIsTyping(false);
    }, 1200); // Slightly longer delay to simulate more thoughtful response
  };

  const findSupportResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();

    // Check against keyword patterns
    for (const response of HEALTHCARE_RESPONSES) {
      if (response.keywords.some(keyword => lowerQuery.includes(keyword))) {
        return response.response;
      }
    }

    // If it includes a question about the app or AVA
    if (
      lowerQuery.includes("ava") ||
      lowerQuery.includes("app") ||
      lowerQuery.includes("how do i") ||
      lowerQuery.includes("how to")
    ) {
      return "I'd be happy to help with your question about the AVA pill dispenser. Our system helps manage medications through reminders, tracking, and caregiver notifications. Could you please specify which feature you need help with?";
    }

    // Default response
    return "Thank you for reaching out to Healthcare Support. I can help with medication management, scheduling, and connecting you with the right healthcare resources. Could you provide more details about your question or concern?";
  };

  return (
    <div className="fixed bottom-5 left-5 z-50">
      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button
            className="h-14 w-14 rounded-full bg-green-600 hover:bg-green-700 shadow-lg"
            aria-label="Contact healthcare support"
          >
            <Heart className="h-6 w-6" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 sm:w-96 p-0 max-h-[500px] flex flex-col" side="top">
          <div className="bg-green-600 text-white p-3 rounded-t-lg">
            <h3 className="font-bold">Healthcare Support</h3>
            <p className="text-xs opacity-90">Medication management & healthcare resources</p>
          </div>

          <div className="flex-1 p-3 overflow-y-auto max-h-[350px] flex flex-col gap-2">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`${
                  message.sender === "support"
                    ? "bg-green-50 dark:bg-green-900/30 text-slate-800 dark:text-slate-100 rounded-lg p-2 self-start max-w-[85%] border-l-4 border-green-500"
                    : "bg-slate-200 dark:bg-slate-700 rounded-lg p-2 self-end max-w-[85%]"
                }`}
              >
                <p className="text-sm">{message.text}</p>
                <p className="text-xs opacity-70 mt-1 text-right">
                  {message.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
            ))}

            {isTyping && (
              <div className="bg-green-50 dark:bg-green-900/30 rounded-lg p-2 self-start border-l-4 border-green-500">
                <div className="flex gap-1 items-center">
                  <div className="h-2 w-2 bg-green-600 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="h-2 w-2 bg-green-600 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="h-2 w-2 bg-green-600 rounded-full animate-bounce"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-3 border-t flex gap-2">
            <Textarea
              placeholder="Ask about medication management..."
              className="resize-none min-h-[60px]"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              className="bg-green-600 hover:bg-green-700"
            >
              Send
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
